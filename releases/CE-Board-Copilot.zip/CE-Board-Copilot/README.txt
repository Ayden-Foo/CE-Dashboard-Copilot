CE Board

1. Unzip this folder anywhere.
2. Double-click Install.cmd.
3. Click Sign in on the page and use your Microsoft account.

Python is included; nothing else needs installing. Use the CE Board shortcut
on your Desktop afterwards.
